# Warehouse Barcode Scanner App

This full-stack application uses React for the frontend and ASP.NET Core for the backend to scan and save barcodes.

## Structure

- **frontend/** – React app with barcode scanning
- **backend/** – ASP.NET Core Web API
